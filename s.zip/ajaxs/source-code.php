<?php
include('../app/config.php');

    $id = $_POST['id'];
    $query = $connect->query("SELECT * FROM MaNguon WHERE id = '$id'")->fetch_array();    
    $tienphaitra = $query['price'];
    
    if($id != $query['id']){
        echo json_api('ID không tồn tại!','error');
    } else if(!isset($_SESSION['users'])){
     echo json_api('Vui lòng đăng nhập để tiếp tục!','error');
    } else if($getUser['money'] < $tienphaitra) {
        echo json_api('Số dư không đủ để thanh toán!','error');
    } else {
        $inTrue = $connect->query("INSERT INTO `DanhSachCode`(`id`, `username`, `name`, `theme`, `time`, `price`) VALUES (NULL,'".$getUser['username']."','".$query['name']."','".$query['id']."','".time()."','$tienphaitra')");
        if($inTrue){
            $connect->query("UPDATE `Users` SET `money`=`money` - '$tienphaitra' WHERE `username` = '".$getUser['username']."'");
            $connect->query("UPDATE `Users` SET `remoney`=`remoney` + '$tienphaitra' WHERE `username` = '".$getUser['username']."'");
            $connect->query("UPDATE `MaNguon` SET `sold`=`sold` + '1' WHERE `id` = '".$query['id']."'");
            echo json_api('Mua mã nguồn thành công','success');
        } else {
            echo json_api('Không thể thanh toán!','error');
        }
        
    }
?>