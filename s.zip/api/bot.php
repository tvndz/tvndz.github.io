<?php
$botToken = ''; // Token của bot Telegram 
$webhookUrl = 'https://'.$_SERVER['SERVER_NAME'].'/api/mphat.php';

$url = "https://api.telegram.org/bot$botToken/setWebhook?url=$webhookUrl";

$response = file_get_contents($url);
echo $response;
?>