<?php
include('../app/config.php');
unset($_SESSION['users']);
echo redirect('/');
?>